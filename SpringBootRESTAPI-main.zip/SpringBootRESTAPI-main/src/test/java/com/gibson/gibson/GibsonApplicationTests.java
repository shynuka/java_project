package com.gibson.gibson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GibsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
